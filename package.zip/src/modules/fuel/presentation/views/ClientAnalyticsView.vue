<template>
  <div class="analytics-view">
    <div class="header-section">
      <div>
        <h2 class="page-title">Inteligencia Operativa</h2>
        <p class="page-subtitle">Análisis de datos en tiempo real del flujo logístico</p>
      </div>
      <button class="btn-export" @click="exportData" :disabled="orderStore.isLoading">
        <DownloadIcon :size="16" />
        Exportar Data (CSV)
      </button>
    </div>

    <div v-if="orderStore.isLoading" class="loader-state">
      <Loader2Icon class="spinner" :size="32" />
      <p>Procesando cubos de datos operacionales...</p>
    </div>

    <template v-else>
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-icon bg-blue"><DropletIcon :size="20" /></div>
          <div class="kpi-data">
            <span class="kpi-label">Volumen Total Solicitado</span>
            <h3 class="kpi-value">{{ totalGallons.toLocaleString() }} <small>gal</small></h3>
            <span class="kpi-trend">Histórico acumulado</span>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon bg-orange"><ActivityIcon :size="20" /></div>
          <div class="kpi-data">
            <span class="kpi-label">Operaciones Activas</span>
            <h3 class="kpi-value">{{ activeOrdersCount }}</h3>
            <span class="kpi-trend">Pendientes y en ruta</span>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon bg-green"><CheckCircleIcon :size="20" /></div>
          <div class="kpi-data">
            <span class="kpi-label">Tasa de Entrega (SLA)</span>
            <h3 class="kpi-value">{{ deliveryRate }}%</h3>
            <span class="kpi-trend" :class="deliveryRate >= 90 ? 'positive' : 'warning'">
              Pedidos completados
            </span>
          </div>
        </div>
      </div>

      <div class="charts-container">

        <div class="chart-card">
          <div class="chart-header">
            <h4>Distribución de Volumen por Producto</h4>
          </div>
          <div class="chart-wrapper donut-box">
            <apexchart
                v-if="fuelMixSeries.length > 0"
                type="donut"
                height="300"
                :options="fuelMixOptions"
                :series="fuelMixSeries"
            />
            <div v-else class="empty-chart">Sin datos suficientes</div>
          </div>
        </div>

        <div class="chart-card">
          <div class="chart-header">
            <h4>Estado del Flujo Operativo</h4>
          </div>
          <div class="chart-wrapper">
            <apexchart
                type="bar"
                height="300"
                :options="statusChartOptions"
                :series="statusChartSeries"
            />
          </div>
        </div>

      </div>
    </template>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue';
import { useOrderStore } from '@/modules/order-management/application/stores/orderStore';
import { toast } from 'vue-sonner';
import {
  DownloadIcon, DropletIcon, ActivityIcon,
  CheckCircleIcon, Loader2Icon
} from 'lucide-vue-next';

const orderStore = useOrderStore();

onMounted(() => {
  orderStore.fetchOrders();
});

// ==========================================
// CÁLCULO DE KPIs
// ==========================================

const totalGallons = computed(() => {
  return orderStore.orders.reduce((sum, order) => sum + (Number(order.gallons) || 0), 0);
});

const activeOrdersCount = computed(() => {
  return orderStore.orders.filter(o => o.status !== 'DELIVERED').length;
});

const deliveryRate = computed(() => {
  if (orderStore.orders.length === 0) return 0;
  const delivered = orderStore.orders.filter(o => o.status === 'DELIVERED').length;
  return ((delivered / orderStore.orders.length) * 100).toFixed(1);
});

// ==========================================
// GRÁFICO 1: DISTRIBUCIÓN POR PRODUCTO
// ==========================================

const fuelMixData = computed(() => {
  const mix = {};
  orderStore.orders.forEach(order => {
    if (!mix[order.fuelType]) mix[order.fuelType] = 0;
    mix[order.fuelType] += Number(order.gallons) || 0;
  });
  return mix;
});

const fuelMixSeries = computed(() => Object.values(fuelMixData.value));
const fuelMixOptions = computed(() => ({
  labels: Object.keys(fuelMixData.value),
  colors: ['#2563EB', '#10B981', '#F59E0B', '#6B7280'],
  chart: { fontFamily: 'Inter, sans-serif' },
  plotOptions: {
    pie: {
      donut: {
        size: '78%', // FIX: Anillo más sofisticado y delgado
        labels: {
          show: true,
          name: { show: true, fontSize: '13px', color: '#6B7280', offsetY: -4 },
          value: { show: true, fontSize: '26px', fontWeight: 800, color: '#111827', offsetY: 6, formatter: (val) => val.toLocaleString() + ' gal' },
          total: { show: true, label: 'Volumen Total', fontSize: '13px', color: '#6B7280', formatter: () => totalGallons.value.toLocaleString() + ' gal' }
        }
      }
    }
  },
  dataLabels: { enabled: false },
  legend: { position: 'bottom', markers: { radius: 12 } }, // FIX: Marcadores de leyenda circulares perfectos
  stroke: { show: false }
}));

// ==========================================
// GRÁFICO 2: ESTADO OPERATIVO (CORREGIDO)
// ==========================================

const statusData = computed(() => {
  const counts = { 'PENDING_APPROVAL': 0, 'APPROVED': 0, 'IN_TRANSIT': 0, 'DELIVERED': 0 };
  orderStore.orders.forEach(order => {
    if (counts[order.status] !== undefined) counts[order.status]++;
  });
  return counts;
});

const statusChartSeries = computed(() => [{
  name: 'Cantidad de Pedidos',
  data: [
    statusData.value['PENDING_APPROVAL'],
    statusData.value['APPROVED'],
    statusData.value['IN_TRANSIT'],
    statusData.value['DELIVERED']
  ]
}]);

const statusChartOptions = computed(() => ({
  chart: { type: 'bar', toolbar: { show: false }, fontFamily: 'Inter, sans-serif' },
  // FIX: Colores Semánticos para reflejar el estado del pedido
  colors: ['#F59E0B', '#3B82F6', '#6366F1', '#10B981'],
  plotOptions: {
    bar: {
      borderRadius: 4,
      horizontal: true,
      distributed: true, // Asigna un color distinto a cada barra
      dataLabels: { position: 'right' }
    }
  },
  dataLabels: {
    enabled: true,
    textAnchor: 'start',
    style: { colors: ['#111827'], fontSize: '13px', fontWeight: 700 },
    offsetX: 12 // FIX: Separa el número de la barra para que no se asfixie
  },
  xaxis: {
    categories: ['Pendiente Validación', 'Aprobado / Espera', 'En Ruta', 'Entregado'],
    labels: {
      formatter: (val) => Math.floor(val) // Solo números enteros
    },
    tickAmount: Math.max(...statusChartSeries.value[0].data, 1)
  },
  yaxis: { labels: { style: { fontSize: '13px', fontWeight: 600, colors: '#4B5563' } } },
  grid: {
    borderColor: '#F3F4F6',
    strokeDashArray: 4,
    padding: { right: 35 } // FIX: Le da espacio a la derecha del gráfico para que el número quepa
  },
  legend: { show: false },
  tooltip: { y: { formatter: (val) => val + " pedidos" } }
}));

// ==========================================
// ACCIONES
// ==========================================

const exportData = () => {
  toast.success('Data estructurada correctamente.', {
    description: 'El reporte operacional en formato CSV ha sido generado.'
  });
};
</script>

<style scoped>
:root { --text-main: #111827; --text-muted: #6B7280; --border-light: #E5E7EB; }

.analytics-view { padding: 0; font-family: 'Inter', sans-serif; animation: fadeIn 0.4s ease-out; }

/* Cabecera Corporativa */
.header-section { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 24px; border-bottom: 1px solid var(--border-light); padding-bottom: 20px;}
.page-title { font-size: 22px; font-weight: 800; color: var(--text-main); margin: 0 0 4px 0; letter-spacing: -0.5px;}
.page-subtitle { margin: 0; color: var(--text-muted); font-size: 14px; }

.btn-export { display: flex; align-items: center; gap: 8px; padding: 10px 16px; background: white; border: 1px solid var(--border-light); border-radius: 8px; font-size: 13px; font-weight: 600; color: #374151; cursor: pointer; transition: all 0.2s; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
.btn-export:hover:not(:disabled) { background: #F9FAFB; border-color: #D1D5DB; }
.btn-export:disabled { opacity: 0.5; cursor: not-allowed; }

/* Estado de Carga */
.loader-state { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 300px; color: var(--text-muted); }
.spinner { animation: spin 1s linear infinite; margin-bottom: 12px; color: #2563EB; }

/* Tarjetas KPI Corporativas */
.kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 24px; }
.kpi-card { background: white; border: 1px solid var(--border-light); border-radius: 12px; padding: 20px; display: flex; gap: 16px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
.kpi-icon { width: 44px; height: 44px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.bg-blue { background: #EFF6FF; color: #2563EB; }
.bg-orange { background: #FFFBEB; color: #D97706; }
.bg-green { background: #F0FDF4; color: #15803D; }

.kpi-data { display: flex; flex-direction: column; }
.kpi-label { font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;}
.kpi-value { font-size: 24px; font-weight: 800; color: var(--text-main); margin: 0 0 4px 0; }
.kpi-value small { font-size: 14px; font-weight: 600; color: #9CA3AF; }

.kpi-trend { font-size: 12px; font-weight: 500; color: #6B7280; }
.kpi-trend.positive { color: #15803D; font-weight: 600; }
.kpi-trend.warning { color: #D97706; font-weight: 600; }

/* Grillas de Gráficos */
.charts-container { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }

.chart-card { background: white; border: 1px solid var(--border-light); border-radius: 12px; padding: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
.chart-header { margin-bottom: 20px; border-bottom: 1px solid #F3F4F6; padding-bottom: 12px; }
.chart-header h4 { margin: 0; font-size: 15px; font-weight: 700; color: var(--text-main); }

.donut-box { display: flex; justify-content: center; align-items: center; min-height: 300px; }
.empty-chart { color: #9CA3AF; font-size: 14px; font-weight: 500; font-style: italic; }

@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

@media (max-width: 1024px) {
  .charts-container { grid-template-columns: 1fr; }
}
</style>